const { app, BrowserWindow, ipcMain, dialog, clipboard, Menu, shell } = require('electron')
const { spawn } = require('child_process')
const fs = require('fs')
const https = require('https')
const os = require('os')
const path = require('path')
const builtInConfig = require('./built-in-config-manager')
const configManager = require('./config-manager')
const ccSwitch = require('./ccswitch')
const draftManager = require('./draft-manager')
const ptyManager = require('./pty-manager')
const shellMonitor = require('./shell-monitor')
const { createOrchestratorService } = require('./orchestrator-service')
const { initAgent } = require('./agent')


let mainWindow
let selectFolderPromise
let monitorTickInterval = null
let agent = null
let agentInitPromise = null
let clientUserDataDir = null
let autoUpdater = null

const updateState = {
  state: 'idle',
  version: null,
  progress: null,
  error: null
}
let updaterReady = false
let updateInterval = null

const getAutoUpdater = () => {
  if (autoUpdater) return autoUpdater
  try {
    ;({ autoUpdater } = require('electron-updater'))
    return autoUpdater
  } catch (err) {
    console.warn('[mps] Failed to load electron-updater:', err)
    return null
  }
}

const pushUpdateState = (patch = {}) => {
  Object.assign(updateState, patch)
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.send('update:status', updateState)
  }
  if (agent && agent.role === 'host' && typeof agent.broadcast === 'function') {
    agent.broadcast('update.status', updateState)
  }
}

const initAutoUpdater = () => {
  const updateUrl = process.env.MPS_UPDATE_URL
  const allowDev = process.env.MPS_UPDATE_DEV === '1'

  if (!updateUrl) {
    pushUpdateState({ state: 'disabled', error: null })
    return
  }

  if (!app.isPackaged && !allowDev) {
    pushUpdateState({ state: 'disabled', error: null })
    return
  }

  const updater = getAutoUpdater()
  if (!updater) {
    pushUpdateState({ state: 'disabled', error: 'electron-updater unavailable' })
    return
  }

  updaterReady = true
  updater.autoDownload = true
  updater.autoInstallOnAppQuit = true
  updater.setFeedURL({ provider: 'generic', url: updateUrl })

  updater.on('checking-for-update', () => {
    pushUpdateState({ state: 'checking', error: null })
  })

  updater.on('update-available', (info) => {
    pushUpdateState({ state: 'available', version: info?.version || null, error: null })
  })

  updater.on('update-not-available', () => {
    pushUpdateState({ state: 'not-available', error: null })
  })

  updater.on('download-progress', (progress) => {
    const percent = Math.round(progress?.percent || 0)
    pushUpdateState({ state: 'downloading', progress: percent, error: null })
  })

  updater.on('update-downloaded', (info) => {
    pushUpdateState({ state: 'downloaded', version: info?.version || null, error: null })
  })

  updater.on('error', (err) => {
    pushUpdateState({ state: 'error', error: err?.message || String(err) })
  })

  updater.checkForUpdates().catch((err) => {
    pushUpdateState({ state: 'error', error: err?.message || String(err) })
  })

  updateInterval = setInterval(() => {
    updater.checkForUpdates().catch(() => {})
  }, 6 * 60 * 60 * 1000)
}

const ensureClientUserData = () => {
  const base =
    String(process.env.LOCALAPPDATA || '').trim() ||
    (() => {
      try {
        return app.getPath('temp')
      } catch (_) {
        return ''
      }
    })() ||
    os.tmpdir()

  const dir = path.join(base, 'MultipleShell', 'clients', String(process.pid))
  try {
    fs.mkdirSync(dir, { recursive: true })
  } catch (_) {}

  try {
    app.setPath('userData', dir)
  } catch (err) {
    console.warn('[mps] Failed to set client userData:', err)
  }

  return dir
}

const initAgentEarly = () => {
  if (agentInitPromise) return agentInitPromise
  agentInitPromise = (async () => {
    try {
      const instance = await initAgent()
      if (instance.role === 'client') {
        clientUserDataDir = ensureClientUserData()
      }
      agent = instance
      return instance
    } catch (err) {
      console.warn('[mps] initAgent failed, falling back to standalone host mode:', err)
      agent = { role: 'host', broadcast: () => {}, setRequestHandler: () => {}, onNotification: () => {} }
      return agent
    }
  })()
  return agentInitPromise
}

const transcribeAudio = async ({ audioData, format = 'webm' }) => {
  if (!audioData) {
    throw new Error('Invalid audioData')
  }
  if (format && !/^[a-z0-9]+$/.test(format)) {
    throw new Error('Invalid format')
  }

  const apiKey = builtInConfig.getVoiceApiKey()
  if (!apiKey) {
    throw new Error('API密钥未配置')
  }

  const buffer = Buffer.isBuffer(audioData)
    ? audioData
    : Array.isArray(audioData)
    ? Buffer.from(audioData)
    : Buffer.from(audioData)

  const boundary = '----' + Math.random().toString(36).substring(2)
  const parts = [
    Buffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="audio.${format}"\r\nContent-Type: audio/${format}\r\n\r\n`
    ),
    buffer,
    Buffer.from(
      `\r\n--${boundary}\r\nContent-Disposition: form-data; name="model"\r\n\r\nFunAudioLLM/SenseVoiceSmall\r\n--${boundary}--\r\n`
    )
  ]
  const body = Buffer.concat(parts)

  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: 'api.siliconflow.cn',
        path: '/v1/audio/transcriptions',
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': `multipart/form-data; boundary=${boundary}`,
          'Content-Length': body.length
        }
      },
      (res) => {
        let data = ''
        res.on('data', (chunk) => (data += chunk))
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data)
            res.statusCode === 200 ? resolve(parsed) : reject(new Error(parsed.message || data))
          } catch {
            reject(new Error(data))
          }
        })
      }
    )
    req.on('error', reject)
    req.write(body)
    req.end()
  })
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 920,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    roundedCorners: true,
    icon: path.join(__dirname, '../../build/icon.ico'),
    resizable: true,
    maximizable: true,
    minimizable: true,       // 保留最小化
    fullscreenable: false,   // 禁止全屏
    center: true,           // 居中显示
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  })
  mainWindow.setMenuBarVisibility(false)

  const session = mainWindow.webContents.session
  session.setPermissionRequestHandler((webContents, permission, callback, details) => {
    if (permission === 'microphone') {
      callback(true)
      return
    }
    if (permission !== 'media') {
      callback(false)
      return
    }

    const mediaTypes = Array.isArray(details?.mediaTypes) ? details.mediaTypes : []
    const mediaType = details?.mediaType
    const wantsVideo = mediaTypes.includes('video') || mediaType === 'video'
    const wantsAudio = mediaTypes.includes('audio') || mediaType === 'audio' || (!mediaTypes.length && !mediaType)
    callback(wantsAudio && !wantsVideo)
  })

  session.setPermissionCheckHandler((webContents, permission, origin, details) => {
    if (permission === 'microphone') return true
    if (permission !== 'media') return false
    const mediaTypes = Array.isArray(details?.mediaTypes) ? details.mediaTypes : []
    const mediaType = details?.mediaType
    const wantsVideo = mediaTypes.includes('video') || mediaType === 'video'
    const wantsAudio = mediaTypes.includes('audio') || mediaType === 'audio' || (!mediaTypes.length && !mediaType)
    return wantsAudio && !wantsVideo
  })

  if (process.env.NODE_ENV === 'development') {
    mainWindow.loadURL('http://localhost:5173')
    mainWindow.webContents.openDevTools()
  } else {
    mainWindow.loadFile(path.join(__dirname, '../../dist/index.html'))
  }

  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F12') {
      mainWindow.webContents.toggleDevTools()
    }
  })
}

const sendToRenderer = (channel, payload) => {
  if (!mainWindow || mainWindow.isDestroyed()) return
  const contents = mainWindow.webContents
  if (!contents || contents.isDestroyed()) return
  contents.send(channel, payload)
}

const sessionRegistry = new Map()
const getSessionsList = () =>
  Array.from(sessionRegistry.values()).sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)))

const broadcastSessionsChanged = () => {
  const list = getSessionsList()
  sendToRenderer('sessions:changed', list)
  if (agent && agent.role === 'host') {
    agent.broadcast('sessions.changed', list)
  }
}

const forwardHostNotification = (method, params) => {
  if (method === 'terminal.data') return sendToRenderer('terminal:data', params)
  if (method === 'terminal.exit') return sendToRenderer('terminal:exit', params)
  if (method === 'sessions.changed') return sendToRenderer('sessions:changed', params)
  if (method === 'monitor.update') return sendToRenderer('monitor:update', params)
  if (method === 'update.status') return sendToRenderer('update:status', params)
  if (method === 'agent.log') return sendToRenderer('agent:log', params)
}

let orchestrator = null
const AGENT_LOG_LIMIT = 400
let agentLogSeq = 1
let plannerSessionId = ''
const agentLogs = []

const makeAgentLogId = () => `a${Date.now().toString(36)}_${(agentLogSeq++).toString(36)}`

const summarizeToolParams = (method, params) => {
  const m = typeof method === 'string' ? method.trim() : ''
  const p = params && typeof params === 'object' && !Array.isArray(params) ? params : {}

  if (m === 'tabs.send') {
    const sessionId = typeof p.sessionId === 'string' ? p.sessionId.trim() : ''
    const sessionIds = Array.isArray(p.sessionIds) ? p.sessionIds.map((s) => String(s || '').trim()).filter(Boolean).slice(0, 10) : []
    const enter = p.enter == null ? true : Boolean(p.enter)
    const text = typeof p.text === 'string' ? clampText(p.text, 240) : ''
    return { sessionId, sessionIds, enter, text }
  }

  if (m === 'tabs.create') {
    const configId = typeof p.configId === 'string' ? p.configId.trim() : ''
    const workingDir = typeof p.workingDir === 'string' ? clampText(p.workingDir.trim(), 200) : ''
    const title = typeof p.title === 'string' ? clampText(p.title.trim(), 120) : ''
    return { configId, workingDir, title }
  }

  if (m === 'tabs.kill' || m === 'tabs.destroy') {
    const sessionId = typeof p.sessionId === 'string' ? p.sessionId.trim() : ''
    return { sessionId }
  }

  if (m === 'monitor.getState') {
    const sessionId = typeof p.sessionId === 'string' ? p.sessionId.trim() : ''
    return { sessionId }
  }

  return {}
}

const summarizeToolResult = (method, result) => {
  const m = typeof method === 'string' ? method.trim() : ''
  const r = result && typeof result === 'object' && !Array.isArray(result) ? result : {}

  if (m === 'configs.list') {
    const count = Array.isArray(r.configs) ? r.configs.length : 0
    return { configCount: count }
  }

  if (m === 'tabs.list' || m === 'sessions.list') {
    const count = Array.isArray(r.sessions) ? r.sessions.length : 0
    return { sessionCount: count }
  }

  if (m === 'tabs.create') {
    return { sessionId: typeof r.sessionId === 'string' ? r.sessionId : '' }
  }

  if (m === 'tabs.kill' || m === 'tabs.destroy') {
    return { ok: Boolean(r.ok) }
  }

  if (m === 'tabs.send') {
    return { sent: typeof r.sent === 'number' ? r.sent : null }
  }

  if (m === 'monitor.getStates') {
    const states = Array.isArray(r.states) ? r.states : []
    const stats = { starting: 0, running: 0, idle: 0, completed: 0, stuck: 0, error: 0, stopped: 0 }
    for (const s of states) {
      const st = typeof s?.status === 'string' ? s.status : ''
      if (stats[st] == null) continue
      stats[st] += 1
    }
    return { sessionCount: states.length, stats }
  }

  if (m === 'monitor.getState') {
    const state = r.state && typeof r.state === 'object' ? r.state : null
    const status = typeof state?.status === 'string' ? state.status : ''
    return { status: status || null }
  }

  return null
}

const emitAgentLog = (entry) => {
  sendToRenderer('agent:log', entry)
  if (agent && agent.role === 'host') {
    try {
      agent.broadcast('agent.log', entry)
    } catch (_) {}
  }
}

const pushAgentLog = (patch) => {
  const entry = {
    id: makeAgentLogId(),
    ts: new Date().toISOString(),
    plannerSessionId,
    ...patch
  }

  agentLogs.push(entry)
  while (agentLogs.length > AGENT_LOG_LIMIT) agentLogs.shift()
  emitAgentLog(entry)
  return entry
}

const clearAgentLogs = () => {
  agentLogs.length = 0
  emitAgentLog({
    id: makeAgentLogId(),
    ts: new Date().toISOString(),
    plannerSessionId,
    type: 'clear'
  })
}

const setPlannerSessionId = (sessionId, source = '') => {
  const next = typeof sessionId === 'string' ? sessionId.trim() : ''
  if (!next) return false
  if (plannerSessionId === next) return false
  plannerSessionId = next
  pushAgentLog({
    type: 'planner',
    sessionId: next,
    message: `planner=${next}${source ? ` (${source})` : ''}`
  })
  return true
}

const sendFromHostPty = (channel, payload) => {
  // Host instance also has a local UI.
  sendToRenderer(channel, payload)

  if (agent && agent.role === 'host') {
    if (channel === 'terminal:data') agent.broadcast('terminal.data', payload)
    if (channel === 'terminal:exit') agent.broadcast('terminal.exit', payload)
  }

  if (channel === 'terminal:data') {
    const sid = payload?.sessionId
    const data = payload?.data
    if (orchestrator && typeof orchestrator.onTerminalData === 'function') {
      orchestrator.onTerminalData(sid, data).catch((err) => {
        console.warn('[mps] Orchestrator tool-call failed:', err)
      })
    }
  }

  if (channel === 'terminal:exit') {
    const sid = payload?.sessionId
    if (typeof sid === 'string' && sid) {
      try {
        orchestrator?.onTerminalExit?.(sid)
      } catch (_) {}
      if (sessionRegistry.delete(sid)) broadcastSessionsChanged()
    }
  }
}

function clampText(value, max = 2000) {
  const text = String(value || '')
  const m = Number(max)
  if (!Number.isFinite(m) || m <= 0) return ''
  if (text.length <= m) return text
  if (m <= 3) return text.slice(0, m)
  return text.slice(0, m - 3) + '...'
}

const isHighRiskSendText = (text) => {
  const t = String(text || '').toLowerCase()
  if (!t.trim()) return false
  const patterns = [
    /\brm\s+-rf\b/,
    /\brmdir\b.*\s\/s\b/,
    /\brd\b.*\s\/s\b/,
    /\bdel\b.*\s\/s\b/,
    /\bformat\s+[a-z]:/,
    /\bdiskpart\b/,
    /\bshutdown\b/,
    /\bstop-computer\b/,
    /\brestart-computer\b/,
    /\bremove-item\b.*\s-recurse\b.*\s-force\b/,
    /\breg\s+delete\b/,
    /\bbcdedit\b/
  ]
  return patterns.some((re) => re.test(t))
}

const confirmHighRiskSend = async (details) => {
  if (process.env.MPS_DISABLE_ORCHESTRATOR_CONFIRM === '1') return true
  if (process.env.MPS_SUPPRESS_DIALOGS === '1') {
    const err = new Error('Dialogs suppressed; blocked high-risk tabs.send')
    err.code = 'DIALOGS_SUPPRESSED'
    throw err
  }

  const target = String(details?.target || '').trim()
  const snippet = clampText(details?.text || '', 600)
  const res = await dialog.showMessageBox({
    type: 'warning',
    buttons: ['Cancel', 'Send'],
    defaultId: 0,
    cancelId: 0,
    noLink: true,
    title: 'Confirm high-risk command send',
    message: 'A Planner (Main Agent) requested sending a high-risk command to a tab.',
    detail: `Target: ${target || '(unknown)'}\n\nCommand:\n${snippet}`
  })
  return res?.response === 1
}

orchestrator = createOrchestratorService({
  onEvent: (evt) => {
    if (!evt || typeof evt !== 'object') return
    if (evt.type === 'tool_call') {
      setPlannerSessionId(evt.sessionId, 'tool_call')
      pushAgentLog({
        type: 'tool_call',
        sessionId: evt.sessionId,
        toolId: evt.id,
        method: evt.method,
        params: summarizeToolParams(evt.method, evt.params),
        message: `${evt.method} (${evt.id})`
      })
      return
    }

    if (evt.type === 'tool_result') {
      pushAgentLog({
        type: 'tool_result',
        sessionId: evt.sessionId,
        toolId: evt.id,
        method: evt.method,
        ok: Boolean(evt.ok),
        result: evt.ok ? summarizeToolResult(evt.method, evt.result) : null,
        error: !evt.ok ? evt.error : null,
        message: `${evt.ok ? 'ok' : 'error'} ${evt.method} (${evt.id})`
      })
    }
  },
  writeToSession: (sessionId, data) => {
    const sid = typeof sessionId === 'string' ? sessionId.trim() : ''
    if (!sid) return
    if (typeof data !== 'string' || !data) return
    try {
      shellMonitor.onUserInput(sid, data)
    } catch (_) {}
    ptyManager.writeToSession(sid, data)
  },
  dispatch: async ({ id, method, params }) => {
    const safeMethod = typeof method === 'string' ? method.trim() : ''
    const p = params && typeof params === 'object' && !Array.isArray(params) ? params : {}

    if (safeMethod === 'tools.list') {
      return {
        tools: [
          { method: 'tools.list', params: {}, description: 'List available orchestrator tools.' },
          { method: 'configs.list', params: {}, description: 'List available config templates (safe summary only).' },
          { method: 'tabs.list', params: {}, description: 'List existing tabs/sessions.' },
          { method: 'tabs.create', params: { configId: '...', workingDir: '', title: '' }, description: 'Create a new tab from an existing config template.' },
          { method: 'tabs.kill', params: { sessionId: '...' }, description: 'Kill/destroy a tab/session.' },
          { method: 'tabs.send', params: { sessionId: '...', text: '...', enter: true }, description: 'Send text to a tab (optionally press Enter).' },
          { method: 'monitor.getStates', params: {}, description: 'Get monitor states for all sessions.' },
          { method: 'monitor.getState', params: { sessionId: '...' }, description: 'Get monitor state for one session.' }
        ]
      }
    }

    if (safeMethod === 'configs.list') {
      const list = configManager.loadConfigs()
      return {
        configs: (Array.isArray(list) ? list : []).map((cfg) => ({
          id: typeof cfg?.id === 'string' ? cfg.id : '',
          type: typeof cfg?.type === 'string' ? cfg.type : '',
          name: typeof cfg?.name === 'string' ? cfg.name : ''
        }))
      }
    }

    if (safeMethod === 'tabs.list' || safeMethod === 'sessions.list') {
      return { sessions: getSessionsList() }
    }

    if (safeMethod === 'tabs.create') {
      const configId = typeof p?.configId === 'string' ? p.configId.trim() : ''
      if (!configId) throw new Error('tabs.create requires configId')

      const workingDir = typeof p?.workingDir === 'string' ? p.workingDir.trim() : ''
      if (workingDir && !isPathSafe(workingDir)) {
        const err = new Error('Unsafe workingDir')
        err.code = 'UNSAFE_WORKDIR'
        throw err
      }

      const configs = configManager.loadConfigs()
      const cfg = (Array.isArray(configs) ? configs : []).find((c) => String(c?.id || '').trim() === configId)
      if (!cfg) {
        const err = new Error(`Config not found: ${configId}`)
        err.code = 'CONFIG_NOT_FOUND'
        throw err
      }

      const title = typeof p?.title === 'string' ? p.title.trim() : ''
      const sessionId = await ptyManager.createSession(cfg, workingDir, sendFromHostPty)
      sessionRegistry.set(sessionId, {
        sessionId,
        title: title || (typeof cfg?.name === 'string' ? cfg.name : 'Unnamed'),
        config: {
          id: typeof cfg?.id === 'string' ? cfg.id : '',
          type: typeof cfg?.type === 'string' ? cfg.type : '',
          name: typeof cfg?.name === 'string' ? cfg.name : ''
        },
        workingDir: workingDir || '',
        createdAt: new Date().toISOString()
      })
      broadcastSessionsChanged()
      return { sessionId }
    }

    if (safeMethod === 'tabs.kill' || safeMethod === 'tabs.destroy') {
      const sessionId = typeof p?.sessionId === 'string' ? p.sessionId.trim() : ''
      if (!sessionId) throw new Error('tabs.kill requires sessionId')
      ptyManager.killSession(sessionId)
      if (sessionRegistry.delete(sessionId)) broadcastSessionsChanged()
      return { ok: true }
    }

    if (safeMethod === 'tabs.send') {
      const text = typeof p?.text === 'string' ? p.text : ''
      if (!text) throw new Error('tabs.send requires text')
      if (text.length > 64 * 1024) {
        const err = new Error('tabs.send text too large')
        err.code = 'TEXT_TOO_LARGE'
        throw err
      }

      const enter = p?.enter == null ? true : Boolean(p.enter)
      const sessionId = typeof p?.sessionId === 'string' ? p.sessionId.trim() : ''
      const sessionIds = Array.isArray(p?.sessionIds) ? p.sessionIds : []

      const targets = new Set()
      if (sessionId) targets.add(sessionId)
      for (const id of sessionIds) {
        const sid = typeof id === 'string' ? id.trim() : ''
        if (sid) targets.add(sid)
      }
      if (targets.size === 0) throw new Error('tabs.send requires sessionId or sessionIds')

      for (const sid of Array.from(targets)) {
        if (!sessionRegistry.has(sid)) {
          const err = new Error(`Session not found: ${sid}`)
          err.code = 'SESSION_NOT_FOUND'
          throw err
        }
      }

      if (isHighRiskSendText(text)) {
        pushAgentLog({
          type: 'risk_confirm',
          sessionId: plannerSessionId,
          toolId: typeof id === 'string' ? id : '',
          method: 'tabs.send',
          message: 'high-risk tabs.send requires confirmation',
          params: summarizeToolParams('tabs.send', { ...p, text })
        })

        const targetLabel = Array.from(targets)
          .map((sid) => {
            const title = String(sessionRegistry.get(sid)?.title || '').trim()
            return title ? `${sid} (${title})` : sid
          })
          .join(', ')

        const ok = await confirmHighRiskSend({ target: targetLabel, text })
        if (!ok) {
          pushAgentLog({
            type: 'risk_blocked',
            sessionId: plannerSessionId,
            toolId: typeof id === 'string' ? id : '',
            method: 'tabs.send',
            message: 'high-risk tabs.send canceled by user'
          })
          const err = new Error('User canceled high-risk tabs.send')
          err.code = 'USER_CANCELED'
          throw err
        }
      }

      const suffix = enter ? '\r' : ''
      const payload = `${text}${suffix}`
      let sent = 0
      for (const sid of Array.from(targets)) {
        shellMonitor.onUserInput(sid, payload)
        ptyManager.writeToSession(sid, payload)
        sent += 1
      }
      return { sent }
    }

    if (safeMethod === 'monitor.getStates') {
      return { states: shellMonitor.getAllStates() }
    }

    if (safeMethod === 'monitor.getState') {
      const sessionId = typeof p?.sessionId === 'string' ? p.sessionId.trim() : ''
      if (!sessionId) throw new Error('monitor.getState requires sessionId')
      const state = shellMonitor.getAllStates().find((s) => s.sessionId === sessionId) || null
      return { state }
    }

    const err = new Error(`Unknown tool method: ${safeMethod || '(empty)'}`)
    err.code = 'UNKNOWN_METHOD'
    throw err
  }
})

shellMonitor.on('update', (payload) => {
  sendToRenderer('monitor:update', payload)
  if (agent && agent.role === 'host') {
    agent.broadcast('monitor.update', payload)
  }

  // Keep session list cwd in sync so the TabBar path reflects runtime `cd` changes.
  try {
    const sid = typeof payload?.sessionId === 'string' ? payload.sessionId : ''
    const cwd = typeof payload?.state?.cwd === 'string' ? payload.state.cwd.trim() : ''
    if (!sid || !cwd) return

    const entry = sessionRegistry.get(sid)
    if (!entry || typeof entry !== 'object') return
    const prev = typeof entry.workingDir === 'string' ? entry.workingDir : ''
    if (prev === cwd) return
    entry.workingDir = cwd
    broadcastSessionsChanged()
  } catch (_) {}
})

// Phase 4: elect Host/Client role before app.whenReady() so a Client can switch its Chromium
// profile directory early (avoids concurrent access to the Host profile).
initAgentEarly().catch(() => {})

app.whenReady().then(async () => {
  await initAgentEarly()

  if (agent.role === 'host' && typeof agent.setRequestHandler === 'function') {
    agent.setRequestHandler(async (method, params) => {
      if (method === 'terminal.create') {
        const config = params?.config
        const workingDir = typeof params?.workingDir === 'string' ? params.workingDir : ''
        if (!config || typeof config !== 'object') throw new Error('Invalid config')

        const sessionId = await ptyManager.createSession(config, workingDir, sendFromHostPty)
        sessionRegistry.set(sessionId, {
          sessionId,
          title: typeof config?.name === 'string' ? config.name : 'Unnamed',
          config: {
            id: typeof config?.id === 'string' ? config.id : '',
            type: typeof config?.type === 'string' ? config.type : '',
            name: typeof config?.name === 'string' ? config.name : ''
          },
          workingDir: workingDir || '',
          createdAt: new Date().toISOString()
        })
        broadcastSessionsChanged()
        return sessionId
      }

      if (method === 'terminal.write') {
        const sessionId = typeof params?.sessionId === 'string' ? params.sessionId : ''
        const data = typeof params?.data === 'string' ? params.data : ''
        if (!sessionId.trim()) throw new Error('Invalid sessionId')
        if (data.length > 1024 * 1024) throw new Error('Data too large')
        shellMonitor.onUserInput(sessionId, data)
        ptyManager.writeToSession(sessionId, data)
        return true
      }

      if (method === 'terminal.resize') {
        const sessionId = typeof params?.sessionId === 'string' ? params.sessionId : ''
        const cols = params?.cols
        const rows = params?.rows
        if (!sessionId.trim()) throw new Error('Invalid sessionId')
        if (!Number.isInteger(cols) || cols < 1 || cols > 1000) throw new Error('Invalid cols')
        if (!Number.isInteger(rows) || rows < 1 || rows > 1000) throw new Error('Invalid rows')
        ptyManager.resizeSession(sessionId, cols, rows)
        return true
      }

      if (method === 'terminal.kill') {
        const sessionId = typeof params?.sessionId === 'string' ? params.sessionId : ''
        if (!sessionId.trim()) throw new Error('Invalid sessionId')
        ptyManager.killSession(sessionId)
        if (sessionRegistry.delete(sessionId)) broadcastSessionsChanged()
        return true
      }

      if (method === 'sessions.list') return getSessionsList()
      if (method === 'monitor.getStates') return shellMonitor.getAllStates()

      if (method === 'agent.getState') {
        return { plannerSessionId, logs: agentLogs }
      }
      if (method === 'agent.clearLogs') {
        clearAgentLogs()
        return { ok: true }
      }
      if (method === 'agent.setPlanner') {
        const sid = typeof params?.sessionId === 'string' ? params.sessionId.trim() : ''
        if (!sid) throw new Error('Invalid sessionId')
        if (!sessionRegistry.has(sid)) {
          const err = new Error(`Session not found: ${sid}`)
          err.code = 'SESSION_NOT_FOUND'
          throw err
        }
        setPlannerSessionId(sid, 'remote')
        return { plannerSessionId }
      }
      if (method === 'agent.send') {
        const text = typeof params?.text === 'string' ? params.text : ''
        const enter = params?.enter == null ? true : Boolean(params.enter)
        const targetSessionId = typeof params?.sessionId === 'string' ? params.sessionId.trim() : ''

        if (!text.trim()) throw new Error('agent.send requires text')
        const sid = targetSessionId || plannerSessionId
        if (!sid) {
          const err = new Error('Planner not set')
          err.code = 'PLANNER_NOT_SET'
          throw err
        }
        if (!sessionRegistry.has(sid)) {
          const err = new Error(`Session not found: ${sid}`)
          err.code = 'SESSION_NOT_FOUND'
          throw err
        }

        const suffix = enter ? '\r' : ''
        const data = `${text}${suffix}`
        shellMonitor.onUserInput(sid, data)
        ptyManager.writeToSession(sid, data)

        pushAgentLog({
          type: 'planner_send',
          sessionId: sid,
          message: clampText(text, 240),
          params: { enter }
        })

        return { ok: true }
      }

      if (method === 'configs.list') return configManager.loadConfigs()
      if (method === 'configs.save') {
        const config = params?.config
        if (!config || typeof config !== 'object') throw new Error('Invalid config')
        return configManager.saveConfig(config)
      }
      if (method === 'configs.delete') {
        const configId = typeof params?.configId === 'string' ? params.configId : ''
        if (!configId.trim()) throw new Error('Invalid configId')
        return configManager.deleteConfig(configId)
      }

      if (method === 'ccswitch.providers.list') return ccSwitch.listProviders()
      if (method === 'ccswitch.providers.import') return ccSwitch.importProviders(configManager)
      if (method === 'ccswitch.requests.tail') return ccSwitch.tailRequestPaths(params || {})

      if (method === 'drafts.load') return draftManager.loadDraft(params?.key)
      if (method === 'drafts.save') return draftManager.saveDraft(params?.key, params?.value)
      if (method === 'drafts.delete') return draftManager.deleteDraft(params?.key)

      if (method === 'update.getStatus') return updateState
      if (method === 'update.check') {
        const updater = getAutoUpdater()
        if (!updaterReady) return updateState
        if (!updater) return updateState
        try {
          await updater.checkForUpdates()
        } catch (err) {
          pushUpdateState({ state: 'error', error: err?.message || String(err) })
        }
        return updateState
      }
      if (method === 'update.quitAndInstall') {
        const updater = getAutoUpdater()
        if (!updaterReady) return false
        if (!updater) return false
        updater.quitAndInstall()
        return true
      }

      if (method === 'voice.getApiKey') return builtInConfig.getVoiceApiKey()
      if (method === 'voice.setApiKey') {
        const key = params?.key
        if (typeof key !== 'string') throw new Error('Invalid API key')
        builtInConfig.setVoiceApiKey(key)
        return { success: true }
      }
      if (method === 'voice.transcribe') {
        return transcribeAudio(params || {})
      }

      if (method === 'remote.applyRdpConfig') {
        return applyRdpConfig(params || {})
      }

      throw new Error(`Unknown method: ${method}`)
    })
  }
  if (agent.role === 'client') {
    agent.onNotification((method, params) => forwardHostNotification(method, params))
  }

  // Only the Host process should touch shared temp dirs (e.g. Codex CODEX_HOME staging)
  // otherwise a Client could delete directories still in use by the Host.
  if (agent.role === 'host') {
    ptyManager.cleanupOrphanedTempDirs()
  }

  if (agent.role === 'host') {
    configManager.loadConfigs()
  }
  Menu.setApplicationMenu(null)
  createWindow()

  // When running multi-instance, only Host should perform "side-effect" background work.
  if (agent.role === 'host') {
    initAutoUpdater()
    monitorTickInterval = setInterval(() => {
      shellMonitor.tick()
    }, 1000)
  }

  // Send initial sessions list to renderer (Host has state; Client will call sessions:list).
  if (agent.role === 'host') {
    broadcastSessionsChanged()
  }
})

app.on('window-all-closed', () => {
  if (agent && agent.role === 'host') {
    ptyManager.killAllSessions()
    sessionRegistry.clear()
    broadcastSessionsChanged()
    if (monitorTickInterval) {
      clearInterval(monitorTickInterval)
      monitorTickInterval = null
    }
  }
  if (process.platform !== 'darwin') app.quit()
})

ipcMain.handle('get-configs', () => {
  if (agent && agent.role === 'client') return agent.call('configs.list', {})
  return configManager.loadConfigs()
})

ipcMain.handle('save-config', (event, config) => {
  if (agent && agent.role === 'client') return agent.call('configs.save', { config })
  return configManager.saveConfig(config)
})

ipcMain.handle('delete-config', (event, configId) => {
  if (agent && agent.role === 'client') return agent.call('configs.delete', { configId })
  return configManager.deleteConfig(configId)
})

ipcMain.handle('ccswitch:listProviders', async () => {
  if (agent && agent.role === 'client') return agent.call('ccswitch.providers.list', {})
  return ccSwitch.listProviders()
})

ipcMain.handle('ccswitch:detect', async () => {
  if (agent && agent.role === 'client') {
    try {
      await agent.call('ccswitch.providers.list', {})
      return { exists: true }
    } catch (err) {
      return { exists: false, reason: 'REMOTE_ERROR', message: err?.message ? String(err.message) : String(err || '') }
    }
  }
  return ccSwitch.detect()
})

ipcMain.handle('ccswitch:importProviders', async () => {
  if (agent && agent.role === 'client') return agent.call('ccswitch.providers.import', {})
  return ccSwitch.importProviders(configManager)
})

ipcMain.handle('ccswitch:tailRequestPaths', async (_event, payload) => {
  if (agent && agent.role === 'client') return agent.call('ccswitch.requests.tail', payload || {})
  return ccSwitch.tailRequestPaths(payload || {})
})

ipcMain.handle('create-terminal', async (event, config, workingDir) => {
  if (!config || typeof config !== 'object') {
    throw new Error('Invalid config')
  }
  if (workingDir && typeof workingDir !== 'string') {
    throw new Error('Invalid workingDir')
  }

  if (agent && agent.role === 'client') {
    return agent.call('terminal.create', { config, workingDir: workingDir || '' })
  }

  const sessionId = await ptyManager.createSession(config, workingDir, sendFromHostPty)
  sessionRegistry.set(sessionId, {
    sessionId,
    title: typeof config?.name === 'string' ? config.name : 'Unnamed',
    config: {
      id: typeof config?.id === 'string' ? config.id : '',
      type: typeof config?.type === 'string' ? config.type : '',
      name: typeof config?.name === 'string' ? config.name : ''
    },
    workingDir: workingDir || '',
    createdAt: new Date().toISOString()
  })
  broadcastSessionsChanged()
  return sessionId
})

ipcMain.handle('write-terminal', (event, sessionId, data) => {
  if (typeof sessionId !== 'string' || !sessionId.trim()) {
    throw new Error('Invalid sessionId')
  }
  if (typeof data !== 'string') {
    throw new Error('Invalid data')
  }
  if (data.length > 1024 * 1024) {
    throw new Error('Data too large')
  }

  if (agent && agent.role === 'client') {
    return agent.call('terminal.write', { sessionId, data })
  }

  shellMonitor.onUserInput(sessionId, data)
  ptyManager.writeToSession(sessionId, data)
})

ipcMain.handle('resize-terminal', (event, sessionId, cols, rows) => {
  if (typeof sessionId !== 'string' || !sessionId.trim()) {
    throw new Error('Invalid sessionId')
  }
  if (!Number.isInteger(cols) || cols < 1 || cols > 1000) {
    throw new Error('Invalid cols')
  }
  if (!Number.isInteger(rows) || rows < 1 || rows > 1000) {
    throw new Error('Invalid rows')
  }

  if (agent && agent.role === 'client') {
    return agent.call('terminal.resize', { sessionId, cols, rows })
  }

  ptyManager.resizeSession(sessionId, cols, rows)
})

ipcMain.handle('kill-terminal', (event, sessionId) => {
  if (typeof sessionId !== 'string' || !sessionId.trim()) {
    throw new Error('Invalid sessionId')
  }

  if (agent && agent.role === 'client') {
    return agent.call('terminal.kill', { sessionId })
  }

  ptyManager.killSession(sessionId)
  if (sessionRegistry.delete(sessionId)) broadcastSessionsChanged()
})

ipcMain.handle('monitor:getStates', () => {
  if (agent && agent.role === 'client') return agent.call('monitor.getStates', {})
  return shellMonitor.getAllStates()
})

ipcMain.handle('sessions:list', () => {
  if (agent && agent.role === 'client') return agent.call('sessions.list', {})
  return getSessionsList()
})

ipcMain.handle('agent:getState', () => {
  if (agent && agent.role === 'client') return agent.call('agent.getState', {})
  return { plannerSessionId, logs: agentLogs }
})

ipcMain.handle('agent:clearLogs', () => {
  if (agent && agent.role === 'client') return agent.call('agent.clearLogs', {})
  clearAgentLogs()
  return { ok: true }
})

ipcMain.handle('agent:setPlanner', (_event, sessionId) => {
  const sid = typeof sessionId === 'string' ? sessionId.trim() : ''
  if (agent && agent.role === 'client') return agent.call('agent.setPlanner', { sessionId: sid })
  if (!sid) throw new Error('Invalid sessionId')
  if (!sessionRegistry.has(sid)) {
    const err = new Error(`Session not found: ${sid}`)
    err.code = 'SESSION_NOT_FOUND'
    throw err
  }
  setPlannerSessionId(sid, 'manual')
  return { plannerSessionId }
})

ipcMain.handle('agent:send', (_event, payload) => {
  const input =
    typeof payload === 'string'
      ? { text: payload }
      : payload && typeof payload === 'object'
      ? payload
      : {}

  const text = typeof input.text === 'string' ? input.text : ''
  const enter = input.enter == null ? true : Boolean(input.enter)
  const targetSessionId = typeof input.sessionId === 'string' ? input.sessionId.trim() : ''

  if (agent && agent.role === 'client') {
    return agent.call('agent.send', { sessionId: targetSessionId, text, enter })
  }

  if (!text.trim()) throw new Error('agent.send requires text')
  const sid = targetSessionId || plannerSessionId
  if (!sid) {
    const err = new Error('Planner not set')
    err.code = 'PLANNER_NOT_SET'
    throw err
  }
  if (!sessionRegistry.has(sid)) {
    const err = new Error(`Session not found: ${sid}`)
    err.code = 'SESSION_NOT_FOUND'
    throw err
  }

  const suffix = enter ? '\r' : ''
  const data = `${text}${suffix}`
  shellMonitor.onUserInput(sid, data)
  ptyManager.writeToSession(sid, data)

  pushAgentLog({
    type: 'planner_send',
    sessionId: sid,
    message: clampText(text, 240),
    params: { enter }
  })

  return { ok: true }
})

const FORBIDDEN_PATHS = [
  'C:\\Windows\\System32',
  'C:\\Windows\\SysWOW64',
  'C:\\Program Files',
  'C:\\Program Files (x86)'
]

function isPathSafe(selectedPath) {
  if (!selectedPath) return false
  const normalized = path.normalize(selectedPath).toLowerCase()
  return !FORBIDDEN_PATHS.some(forbidden =>
    normalized.startsWith(path.normalize(forbidden).toLowerCase())
  )
}

ipcMain.handle('select-folder', async () => {
  if (selectFolderPromise) {
    const result = await selectFolderPromise
    return result.canceled ? null : result.filePaths[0]
  }
  selectFolderPromise = dialog.showOpenDialog({ properties: ['openDirectory'] })
  try {
    const result = await selectFolderPromise
    if (!result.canceled && result.filePaths[0]) {
      const selectedPath = result.filePaths[0]
      if (!isPathSafe(selectedPath)) {
        dialog.showErrorBox('路径不安全', '不允许选择系统目录')
        return null
      }
      return selectedPath
    }
    return null
  } finally {
    selectFolderPromise = null
  }
})

ipcMain.handle('get-default-cwd', () => {
  return process.env.USERPROFILE || ''
})

ipcMain.handle('app:getVersion', () => app.getVersion())

ipcMain.handle('update:getStatus', () => {
  if (agent && agent.role === 'client') return agent.call('update.getStatus', {})
  return updateState
})

ipcMain.handle('update:check', async () => {
  if (agent && agent.role === 'client') return agent.call('update.check', {})
  if (!updaterReady) return updateState
  const updater = getAutoUpdater()
  if (!updater) return updateState
  try {
    await updater.checkForUpdates()
  } catch (err) {
    pushUpdateState({ state: 'error', error: err?.message || String(err) })
  }
  return updateState
})

ipcMain.handle('update:quitAndInstall', () => {
  if (agent && agent.role === 'client') return agent.call('update.quitAndInstall', {})
  if (!updaterReady) return false
  const updater = getAutoUpdater()
  if (!updater) return false
  updater.quitAndInstall()
  return true
})

ipcMain.handle('voice:getApiKey', () => {
  if (agent && agent.role === 'client') return agent.call('voice.getApiKey', {})
  return builtInConfig.getVoiceApiKey()
})

ipcMain.handle('voice:setApiKey', (_, key) => {
  if (agent && agent.role === 'client') return agent.call('voice.setApiKey', { key })
  if (typeof key !== 'string') {
    throw new Error('Invalid API key')
  }
  builtInConfig.setVoiceApiKey(key)
  return { success: true }
})

ipcMain.handle('voice:transcribe', async (_, payload) => {
  if (agent && agent.role === 'client') return agent.call('voice.transcribe', payload || {})
  return transcribeAudio(payload || {})
})

ipcMain.handle('window:minimize', () => {
  if (mainWindow) mainWindow.minimize()
})

ipcMain.handle('window:toggle-maximize', () => {
  if (!mainWindow) return
  if (mainWindow.isMaximized()) mainWindow.unmaximize()
  else mainWindow.maximize()
})

ipcMain.handle('window:close', () => {
  if (mainWindow) mainWindow.close()
})

ipcMain.handle('clipboard:writeText', (event, text) => {
  clipboard.writeText(text == null ? '' : String(text))
  return true
})

ipcMain.handle('clipboard:readText', () => {
  return clipboard.readText()
})

ipcMain.handle('shell:openExternal', async (event, url) => {
  if (typeof url !== 'string' || !url.trim()) {
    throw new Error('Invalid url')
  }
  if (url.length > 4096) {
    throw new Error('URL too long')
  }

  let parsed
  try {
    parsed = new URL(url)
  } catch (_) {
    throw new Error('Invalid URL')
  }

  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    throw new Error('Unsupported protocol')
  }

  await shell.openExternal(url)
  return true
  })

const runPowerShell = (scriptText) =>
  new Promise((resolve, reject) => {
    const child = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', scriptText], {
      windowsHide: true
    })

    let stdout = ''
    let stderr = ''

    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString()
    })
    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString()
    })
    child.on('error', (err) => reject(err))
    child.on('close', (code) => {
      if (code === 0) return resolve({ stdout, stderr })
      const message = (stderr || stdout || '').trim() || `PowerShell exited with code ${code}`
      const err = new Error(message)
      err.code = code
      err.stdout = stdout
      err.stderr = stderr
      reject(err)
    })
  })

const resolveRemoteAppExePath = () => {
  const override = String(process.env.MPS_REMOTEAPP_EXE_PATH ?? '').trim()
  if (override) {
    if (!fs.existsSync(override)) {
      throw new Error(`MPS_REMOTEAPP_EXE_PATH not found: ${override}`)
    }
    return override
  }

  const currentExe = String(app.getPath('exe') ?? '').trim()

  // Packaged app: use the real installed executable path.
  if (app.isPackaged) return currentExe

  // Dev mode: avoid registering "electron.exe", which will show "electron.exe path-to-app".
  const exeName = path.basename(currentExe).toLowerCase()
  if (exeName !== 'electron.exe') return currentExe

  const repoRoot = path.resolve(__dirname, '../..')
  const productExe = 'MultipleShell.exe'

  const candidates = []

  // 1) Prefer the unpacked build output when developing (matches the current repo code/version).
  const archFolder = process.arch === 'ia32' ? 'ia32' : process.arch === 'arm64' ? 'arm64' : 'x64'
  candidates.push(path.join(repoRoot, 'release', archFolder, 'win-unpacked', productExe))

  try {
    const releaseDir = path.join(repoRoot, 'release')
    const entries = fs.readdirSync(releaseDir, { withFileTypes: true })
    for (const entry of entries) {
      if (!entry.isDirectory()) continue
      candidates.push(path.join(releaseDir, entry.name, 'win-unpacked', productExe))
    }
  } catch (_) {}

  // 2) Fall back to common install locations (in case you're running dev but have installed the app).
  const localAppData = String(process.env.LOCALAPPDATA ?? '').trim()
  if (localAppData) {
    candidates.push(path.join(localAppData, 'Programs', 'MultipleShell', productExe))
  }

  const programFiles = String(process.env.ProgramFiles ?? '').trim()
  if (programFiles) {
    candidates.push(path.join(programFiles, 'MultipleShell', productExe))
  }

  const programFilesX86 = String(process.env['ProgramFiles(x86)'] ?? '').trim()
  if (programFilesX86) {
    candidates.push(path.join(programFilesX86, 'MultipleShell', productExe))
  }

  for (const candidate of candidates) {
    if (candidate && fs.existsSync(candidate)) return candidate
  }

  throw new Error(
    'Cannot resolve MultipleShell.exe for RemoteApp registration. Build (release/*/win-unpacked), install the app, or set MPS_REMOTEAPP_EXE_PATH.'
  )
}

ipcMain.handle('app:getInstanceCount', async () => {
  if (process.platform !== 'win32') return 1

  const exeName = 'MultipleShell.exe'
  const script = `
$ErrorActionPreference = "Stop"
$exe = "${exeName}"

$procs = @()
try {
  $procs = Get-CimInstance Win32_Process -Filter ("Name='" + $exe + "'") -ErrorAction SilentlyContinue
} catch {
  $procs = @()
}

if (-not $procs) {
  Write-Output 0
  exit 0
}

# One Electron app instance roughly maps to one "browser" (main) process which does not have --type=...
$mainCount = ($procs | Where-Object { $_.CommandLine -notmatch "--type=" } | Measure-Object).Count
Write-Output $mainCount
`

  try {
    const { stdout } = await runPowerShell(script)
    const raw = String(stdout || '').trim()
    const count = Number.parseInt(raw, 10)
    return Number.isFinite(count) ? count : 0
  } catch (err) {
    console.warn('[mps] app:getInstanceCount failed', err)
    return 0
  }
})

const applyRdpConfig = async (payload) => {
  if (process.platform !== 'win32') {
    throw new Error('RDP config is only supported on Windows')
  }

  const port = Number.parseInt(String(payload?.systemRdpPort ?? ''), 10)
  if (!Number.isFinite(port) || port < 1 || port > 65535) {
    throw new Error('Invalid systemRdpPort')
  }

  const remoteAppAlias = 'MultipleShell'
  const exePath = resolveRemoteAppExePath()
  const psPayload = { port, alias: remoteAppAlias, exePath }
  const psJson = JSON.stringify(psPayload).replace(/'/g, "''")

  const script = `
$ErrorActionPreference = "Stop"
$payload = '${psJson}' | ConvertFrom-Json
$port = [int]$payload.port
$alias = [string]$payload.alias
$exePath = [string]$payload.exePath

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw "Run MultipleShell as Administrator to apply RDP config."
}

function Set-RegistryDword {
  Param([string]$Path,[string]$Name,[int]$Value)
  New-ItemProperty -Path $Path -Name $Name -PropertyType DWord -Value $Value -Force | Out-Null
}

function Set-RegistryString {
  Param([string]$Path,[string]$Name,[string]$Value)
  New-ItemProperty -Path $Path -Name $Name -PropertyType String -Value $Value -Force | Out-Null
}

# Enable RDP + NLA
Set-RegistryDword -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server" -Name "fDenyTSConnections" -Value 0
Set-RegistryDword -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp" -Name "UserAuthentication" -Value 1

# Windows Firewall: inbound TCP
if (Get-Command New-NetFirewallRule -ErrorAction SilentlyContinue) {
  $ruleName = "MultipleShell-RDP-" + $port
  $existing = Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue
  if (-not $existing) {
    New-NetFirewallRule -Name $ruleName -DisplayName ("MultipleShell RDP (TCP " + $port + ")") -Direction Inbound -Action Allow -Enabled True -Protocol TCP -LocalPort $port -Profile Any | Out-Null
  }
}

# RemoteApp allow list (mstsc: remoteapplicationprogram:s:||<alias>)
$base = "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Terminal Server\\TSAppAllowList"
if (-not (Test-Path -LiteralPath $base)) { New-Item -Path $base -Force | Out-Null }
Set-RegistryDword -Path $base -Name "fDisabledAllowList" -Value 0

$appsKey = Join-Path $base "Applications"
if (-not (Test-Path -LiteralPath $appsKey)) { New-Item -Path $appsKey -Force | Out-Null }

$appKey = Join-Path $appsKey $alias
if (-not (Test-Path -LiteralPath $appKey)) { New-Item -Path $appKey -Force | Out-Null }

Set-RegistryString -Path $appKey -Name "Name" -Value $alias
Set-RegistryString -Path $appKey -Name "Path" -Value $exePath
Set-RegistryString -Path $appKey -Name "IconPath" -Value $exePath
Set-RegistryDword -Path $appKey -Name "IconIndex" -Value 0
Set-RegistryDword -Path $appKey -Name "ShowInTSWA" -Value 1
Set-RegistryDword -Path $appKey -Name "CommandLineSetting" -Value 0
Set-RegistryString -Path $appKey -Name "RequiredCommandLine" -Value ""
`

  await runPowerShell(script)
  return { ok: true, port, alias: remoteAppAlias, exePath }
}

ipcMain.handle('remote:applyRdpConfig', async (event, payload) => {
  if (agent && agent.role === 'client') {
    return agent.call('remote.applyRdpConfig', payload || {})
  }
  return applyRdpConfig(payload || {})
})

ipcMain.handle('draft:load', (event, key) => {
  if (agent && agent.role === 'client') return agent.call('drafts.load', { key })
  return draftManager.loadDraft(key)
})

ipcMain.handle('draft:save', (event, key, value) => {
  if (agent && agent.role === 'client') return agent.call('drafts.save', { key, value })
  return draftManager.saveDraft(key, value)
})

ipcMain.handle('draft:delete', (event, key) => {
  if (agent && agent.role === 'client') return agent.call('drafts.delete', { key })
  return draftManager.deleteDraft(key)
})

